import React, { useState, useEffect } from 'react';
import { motion, useScroll, useTransform } from 'motion/react';
import { 
  Tractor, 
  Settings, 
  MapPin, 
  History, 
  Search, 
  User, 
  Globe, 
  HardHat, 
  Handshake, 
  Cog, 
  ArrowRight,
  LogOut // Used as portal icon
} from 'lucide-react';

export default function App() {
  const [isScrolled, setIsScrolled] = useState(false);
  const { scrollY } = useScroll();
  const heroY = useTransform(scrollY, [0, 1000], [0, 300]);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white font-sans overflow-x-hidden flex flex-col">
      
      {/* 1. Header (Navigation) */}
      <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? 'bg-black/95 backdrop-blur-md border-b-[0.5px] border-bronze/30' : 'bg-transparent border-b-[0.5px] border-bronze/20'}`}>
        {/* Top Nav */}
        <div className="hidden sm:flex items-center px-8 py-2 text-[10px] tracking-widest text-bronze uppercase border-b border-bronze/20">
          <div className="flex items-center w-full">
            {['SCHOTSMAN.LLC', 'NEW EQUIPMENT', 'USED EQUIPMENT', 'SELL EQUIPMENT', 'GLOBAL TRADE'].map((item, idx) => (
              <React.Fragment key={item}>
                <a href="#" className={`px-4 hover:text-white transition-colors ${idx === 0 ? 'pl-0 font-bold' : 'text-white/50'}`}>
                  {item}
                </a>
                {idx < 4 && <span className="h-4 w-[1px] bg-bronze/40"></span>}
              </React.Fragment>
            ))}
            <div className="ml-auto flex items-center">
              <a href="#" className="flex items-center text-white/80 hover:text-white transition-colors">
                <span className="mr-2">CUSTOMER PORTAL</span>
                <LogOut size={12} />
              </a>
            </div>
          </div>
        </div>

        {/* Main Nav */}
        <div className="flex items-center justify-between px-8 py-4">
          <div className="flex items-center gap-8">
            {/* Logo Area */}
            <div className="font-heading font-black text-2xl tracking-tighter flex items-center">
              SCHOTSMAN <span className="text-bronze ml-1">LLC</span>
              <div className="ml-4 h-[1px] w-12 bg-bronze hidden lg:block"></div>
            </div>
            
            {/* Main Links */}
            <nav className="hidden lg:flex items-center gap-6 text-[11px] font-bold tracking-widest uppercase">
              {['REQUEST A QUOTE', 'SERVICE', 'LOCATIONS', 'TRADING HISTORY'].map((item, idx) => (
                <React.Fragment key={item}>
                   <a href="#" className={`${idx === 0 ? 'text-bronze' : 'text-white'} hover:text-bronze transition-colors hover:underline underline-offset-4 decoration-bronze/50`}>
                     {item}
                   </a>
                   {idx < 3 && <span className="h-3 w-[1px] bg-bronze/40"></span>}
                </React.Fragment>
              ))}
            </nav>
          </div>

          <div className="flex items-center gap-4">
            <button className="bg-bronze text-black text-[11px] font-black px-6 py-3 tracking-widest uppercase hover:bg-bronze-dark transition-colors border border-bronze shadow-[0_0_15px_rgba(191,135,79,0.3)]">
              REQUEST A QUOTE
            </button>
            <div className="flex gap-3 text-bronze hidden sm:flex">
              <button className="hover:text-white transition-colors"><Search size={20} /></button>
              <button className="hover:text-white transition-colors"><User size={20} /></button>
            </div>
          </div>
        </div>
      </header>

      {/* 2. Hero Section */}
      <section className="relative h-screen flex flex-col justify-center overflow-hidden">
        {/* Background Parallax */}
        <motion.div 
          style={{ y: heroY }}
          className="absolute inset-0 w-full h-[120%] -top-[10%] z-0"
        >
          <img 
            src="https://picsum.photos/seed/excavator-sunset/1920/1080?blur=1" 
            alt="Heavy Machinery at Sunset"
            className="w-full h-full object-cover opacity-60"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/40 to-transparent"></div>
          <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-transparent to-black"></div>
        </motion.div>

        {/* Hero Content */}
        <div className="relative z-10 px-8 lg:px-12 mt-20 max-w-4xl pt-12">
          <motion.h1 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="font-heading font-black text-5xl md:text-6xl lg:text-[64px] leading-[0.9] tracking-tighter mb-4 uppercase"
          >
            ENGINEERED FOR WORK.<br />
            PROVEN BY EXPERIENCE.<br />
            <span className="text-bronze">YOUR GLOBAL PARTNER.</span>
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }}
            className="text-lg text-white/80 max-w-xl font-light mb-8"
          >
            Schotsman LLC: Your expert in global equipment trading and hands-on operational knowledge.
          </motion.p>
        </div>

        {/* Hero Cards Section */}
        <div className="absolute bottom-0 left-0 w-full z-20">
          <div className="grid grid-cols-1 md:grid-cols-3 bg-black/40 backdrop-blur-md border-t border-b border-bronze/30">
            {/* Card 1 */}
            <div className="p-8 border-b md:border-b-0 md:border-r border-bronze/20 group cursor-pointer hover:bg-black/60 transition-colors relative overflow-hidden">
               <div className="w-8 h-8 mb-4 text-bronze">
                 <Tractor size={32} />
               </div>
               <h3 className="text-[14px] font-heading font-black tracking-[0.2em] mb-2 uppercase">BUILD YOUR FLEET</h3>
               <p className="text-[11px] text-white/60 uppercase tracking-widest mb-4 z-10 relative">The latest in engineered efficiency.</p>
               <span className="inline-block border-b border-bronze pb-1 text-[10px] font-bold uppercase tracking-widest text-bronze group-hover:text-white group-hover:border-white transition-colors relative z-10">View New Inventory</span>
               <Tractor size={64} className="opacity-10 absolute -top-4 -right-16 group-hover:opacity-20 transition-opacity text-bronze pointer-events-none" />
            </div>
            
            {/* Card 2 */}
            <div className="p-8 border-b md:border-b-0 md:border-r border-bronze/20 group cursor-pointer hover:bg-black/60 transition-colors relative overflow-hidden">
               <div className="w-8 h-8 mb-4 text-bronze">
                 <Settings size={32} />
               </div>
               <h3 className="text-[14px] font-heading font-black tracking-[0.2em] mb-2 uppercase">USED EQUIPMENT</h3>
               <p className="text-[11px] text-white/60 uppercase tracking-widest mb-4 z-10 relative">Rugged performance, proven value.</p>
               <span className="inline-block border-b border-bronze pb-1 text-[10px] font-bold uppercase tracking-widest text-bronze group-hover:text-white group-hover:border-white transition-colors relative z-10">View Used Equipment</span>
               <Settings size={64} className="opacity-10 absolute -top-4 -right-16 group-hover:opacity-20 transition-opacity text-bronze pointer-events-none" />
            </div>

            {/* Card 3 */}
            <div className="p-8 group cursor-pointer hover:bg-black/60 transition-colors relative overflow-hidden">
               <div className="w-8 h-8 mb-4 text-bronze">
                 <Handshake size={32} />
               </div>
               <h3 className="text-[14px] font-heading font-black tracking-[0.2em] mb-2 uppercase">SELL YOUR EQUIPMENT</h3>
               <p className="text-[11px] text-white/60 uppercase tracking-widest mb-4 z-10 relative">Global reach for your assets.</p>
               <span className="inline-block border-b border-bronze pb-1 text-[10px] font-bold uppercase tracking-widest text-bronze group-hover:text-white group-hover:border-white transition-colors relative z-10">Begin a Global Deal</span>
               <Handshake size={64} className="opacity-10 absolute -top-4 -right-16 group-hover:opacity-20 transition-opacity text-bronze pointer-events-none" />
            </div>
          </div>
        </div>
      </section>

      {/* 3. Banner Hook */}
      <section className="bg-[linear-gradient(90deg,#000_0%,#111_50%,#000_100%)] border-y border-bronze/20 py-8 flex justify-center items-center overflow-hidden">
        <p className="text-[14px] md:text-[24px] font-heading font-black tracking-[.25em] text-bronze uppercase whitespace-nowrap opacity-90 text-center px-4 truncate">
          OVER 60 YEARS OF COMBINED GLOBAL EXPERTISE AND OPERATOR EXPERIENCE
        </p>
      </section>

      {/* 4. Services Section */}
      <section className="bg-white text-black py-12 lg:py-24">
        <div className="max-w-[1400px] mx-auto px-4 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            {[
              { title: "NEW EQUIPMENT", img: "https://picsum.photos/seed/new-tractor/800/1000", delay: 0 },
              { title: "USED EQUIPMENT", img: "https://picsum.photos/seed/used-excavator/800/1000", delay: 0.1 },
              { title: "SELL YOUR EQUIPMENT", img: "https://picsum.photos/seed/logistics/800/1000", delay: 0.2 }
            ].map((service, i) => (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: service.delay, duration: 0.6 }}
                key={i} 
                className="group relative h-[500px] lg:h-[700px] overflow-hidden bg-neutral-100 cursor-pointer"
              >
                <div className="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition-colors duration-500 z-10"></div>
                <img 
                  src={service.img} 
                  alt={service.title} 
                  className="absolute inset-0 w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-700 ease-out"
                  referrerPolicy="no-referrer"
                />
                
                <div className="absolute bottom-0 left-0 w-full p-8 z-20 flex flex-col items-start translate-y-4 group-hover:translate-y-0 transition-transform duration-500">
                  <div className="w-12 h-[3px] bg-bronze mb-4 transform scale-x-0 group-hover:scale-x-100 transition-transform origin-left duration-500"></div>
                  <h3 className="font-heading font-black text-3xl lg:text-4xl text-white tracking-tighter uppercase mb-4">
                    {service.title}
                  </h3>
                  <span className="flex items-center text-bronze font-bold text-sm tracking-widest uppercase opacity-0 group-hover:opacity-100 transition-opacity duration-500 delay-100">
                    Learn More <ArrowRight size={16} className="ml-2" />
                  </span>
                </div>
              </motion.div>
            ))}

          </div>
        </div>
      </section>

      {/* 5. About Us Section */}
      <section className="bg-black bg-texture-dark border-t-[0.5px] border-bronze/20">
        <div className="flex flex-col lg:flex-row min-h-screen">
          {/* Left Side (Visual) */}
          <div className="lg:w-1/2 relative min-h-[50vh] lg:min-h-full overflow-hidden">
             {/* Collage simulation */}
             <div className="absolute inset-0 bg-neutral-900 mix-blend-multiply z-10"></div>
             <img src="https://picsum.photos/seed/engineers-blueprint/1000/1200?grayscale" alt="Partnership" className="absolute inset-0 w-full h-full object-cover opacity-60" referrerPolicy="no-referrer" />
             <div className="absolute inset-0 z-20 p-12 flex items-end">
               <h2 className="font-heading font-black text-5xl lg:text-7xl tracking-tighter text-white/90 leading-[0.85] mix-blend-overlay">
                 A PARTNERSHIP<br/>BUILT ON<br/><span className="text-bronze">EXPERIENCE.</span>
               </h2>
             </div>
             {/* Abstract mapping lines Overlay */}
             <svg className="absolute inset-0 w-full h-full z-15 opacity-20 text-bronze" xmlns="http://www.w3.org/2000/svg">
                <path d="M100 100 L300 250 L500 150 L800 400" stroke="currentColor" strokeWidth="2" fill="none" />
                <circle cx="300" cy="250" r="4" fill="currentColor" />
                <circle cx="500" cy="150" r="4" fill="currentColor" />
             </svg>
          </div>
          
          {/* Right Side (Text) */}
          <div className="lg:w-1/2 p-8 lg:p-24 flex flex-col justify-center">
            <h2 className="font-heading font-black text-4xl lg:text-5xl tracking-tighter mb-12 uppercase">
              A PARTNERSHIP<br/>BUILT ON EXPERIENCE.
            </h2>
            <div className="space-y-8 font-light text-neutral-300 text-lg leading-relaxed">
              <p>
                <strong className="text-white font-bold">Over 60 Years Combined Experience.</strong> Schotsman LLC is a partnership built on experience, <span className="text-bronze font-medium">integrity</span>, and a deep understanding of the equipment industry.
              </p>
              <p>
                Founded by Hugh Sutherland and Henk Schotsman, our company brings together decades of hands-on knowledge. Henk, based in the <span className="text-bronze font-medium">Netherlands</span>, offers an expansive, proven network for sourcing premium equipment globally. Hugh, operating from <span className="text-bronze font-medium">Hattiesburg, South Mississippi</span>, provides unparalleled operator insight—knowing exactly what it takes for a machine to perform flawlessly on the job site.
              </p>
              <p>
                We don't just trade machinery; we understand the mechanics, the value, and the operational reality of every asset we handle.
              </p>
            </div>
            
            <div className="mt-12 flex gap-6">
               <div className="flex-1 border-t border-bronze/30 pt-4">
                 <p className="font-heading font-bold text-2xl text-white mb-1">HENK SCHOTSMAN</p>
                 <p className="text-sm text-bronze uppercase tracking-widest">European Operations</p>
               </div>
               <div className="flex-1 border-t border-bronze/30 pt-4">
                 <p className="font-heading font-bold text-2xl text-white mb-1">HUGH SUTHERLAND</p>
                 <p className="text-sm text-bronze uppercase tracking-widest">US Operations</p>
               </div>
            </div>
          </div>
        </div>
      </section>

      {/* 6. Why Choose Us */}
      <section className="bg-white text-black py-24">
        <div className="max-w-7xl mx-auto px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
            {[
              { icon: Globe, title: "GLOBAL REACH", desc: "Netherlands-based import/export expertise ensuring worldwide access." },
              { icon: HardHat, title: "OPERATOR KNOWLEDGE", desc: "Experienced from the operator's seat to the dirt of the job site." },
              { icon: Handshake, title: "INTEGRITY", desc: "Transparent trading, honest assessments, and reliable partnerships." },
              { icon: Cog, title: "PROVEN VALUE", desc: "Expertly identifying and securing value where others do not see it." }
            ].map((feature, i) => (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1, duration: 0.5 }}
                key={i} 
                className="flex flex-col items-start border-t border-black/10 pt-8"
              >
                <feature.icon size={48} strokeWidth={1} className="text-bronze mb-6" />
                <h4 className="font-heading font-black text-xl tracking-tight mb-4">{feature.title}</h4>
                <p className="text-neutral-600 leading-relaxed font-light">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* 7. Our Work / Featured Inventory (Dynamic Gallery) */}
      <section className="py-24 bg-neutral-950 border-t border-white/5">
        <div className="max-w-[1600px] mx-auto px-4 lg:px-8">
          <div className="flex items-center justify-between mb-12">
             <h2 className="font-heading font-black text-4xl lg:text-5xl tracking-tighter uppercase text-white">THE SCHOTSMAN STANDARD</h2>
             <div className="hidden md:block h-[1px] flex-1 bg-white/10 mx-8"></div>
             <button className="text-bronze font-bold tracking-widest text-sm uppercase hover:text-white transition-colors flex items-center">
               View All <ArrowRight size={16} className="ml-2" />
             </button>
          </div>
          
          {/* Bento Grid */}
          <div className="grid grid-cols-1 md:grid-cols-4 grid-rows-[300px_300px] gap-4">
            <div className="md:col-span-2 md:row-span-2 relative group overflow-hidden bg-neutral-900 border-[0.5px] border-white/10">
               <img src="https://picsum.photos/seed/massive-excavator/800/800" alt="Work" className="w-full h-full object-cover opacity-80 group-hover:scale-105 transition-transform duration-700" referrerPolicy="no-referrer" />
               <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
               <div className="absolute bottom-6 left-6">
                 <span className="bg-bronze text-black text-xs font-bold px-3 py-1 uppercase tracking-widest mb-3 inline-block">Recently Sourced</span>
                 <p className="font-heading text-xl font-bold">CAT 336 Excavator</p>
               </div>
            </div>
            <div className="relative group overflow-hidden bg-neutral-900 border-[0.5px] border-white/10">
               <img src="https://picsum.photos/seed/bulldozer/600/400" alt="Work" className="w-full h-full object-cover opacity-80 group-hover:scale-105 transition-transform duration-700" referrerPolicy="no-referrer" />
               <div className="absolute bottom-4 left-4">
                 <span className="bg-black/50 backdrop-blur text-white border border-white/20 text-[10px] uppercase px-2 py-1 tracking-wider">Global Deal Closed</span>
               </div>
            </div>
            <div className="relative group overflow-hidden bg-neutral-900 border-[0.5px] border-white/10">
               <img src="https://picsum.photos/seed/port-shipping/600/400" alt="Work" className="w-full h-full object-cover opacity-80 group-hover:scale-105 transition-transform duration-700" referrerPolicy="no-referrer" />
               <div className="absolute bottom-4 left-4">
                 <span className="bg-black/50 backdrop-blur text-white border border-white/20 text-[10px] uppercase px-2 py-1 tracking-wider">Logistics Routing</span>
               </div>
            </div>
            <div className="md:col-span-2 relative group overflow-hidden bg-neutral-900 border-[0.5px] border-white/10">
               <img src="https://picsum.photos/seed/jobsite-action/800/400" alt="Work" className="w-full h-full object-cover opacity-80 group-hover:scale-105 transition-transform duration-700" referrerPolicy="no-referrer" />
               <div className="absolute bottom-4 left-4">
                 <span className="bg-black/50 backdrop-blur text-white border border-white/20 text-[10px] uppercase px-2 py-1 tracking-wider">On-Site Inspection</span>
               </div>
            </div>
          </div>
        </div>
      </section>

      {/* 8. Call to Action */}
      <section className="relative py-32 bg-black overflow-hidden flex items-center justify-center border-y border-bronze/30">
        <div className="absolute inset-0 opacity-40">
          <img src="https://picsum.photos/seed/industrial-sunset-wide/1920/600" alt="Sunset Port" className="w-full h-full object-cover scale-105" referrerPolicy="no-referrer" />
          <div className="absolute inset-0 bg-black/60 mix-blend-multiply"></div>
        </div>
        
        <div className="relative z-10 text-center px-4 max-w-4xl">
          <h2 className="font-heading font-black text-4xl md:text-6xl tracking-tighter uppercase mb-6 drop-shadow-2xl">
            READY TO SELL OR SOURCING A MACHINE GLOBALLY?
          </h2>
          <p className="text-xl text-neutral-300 font-light mb-12 drop-shadow-md">
            Connect with Schotsman LLC for expert advice on buying, selling, and sourcing heavy equipment globally.
          </p>
          <div className="flex flex-col sm:flex-row gap-6 justify-center">
            <button className="bg-bronze hover:bg-white hover:text-black text-white font-heading font-bold tracking-widest text-sm px-10 py-5 transition-colors border border-bronze hover:border-white">
              CONTACT OUR TEAM
            </button>
            <button className="bg-transparent hover:bg-bronze text-white font-heading font-bold tracking-widest text-sm px-10 py-5 transition-colors border border-bronze">
              VIEW USED INVENTORY
            </button>
          </div>
        </div>
      </section>

      {/* 9. Footer */}
      <footer className="bg-neutral-950 pt-0 relative z-10">
        
        {/* Top Search Bar */}
        <div className="bg-white w-full py-4 px-8 lg:px-12 flex items-center justify-between border-t border-b-4 border-bronze">
          <div className="flex items-center flex-1 max-w-[1600px] mx-auto">
            <span className="text-bronze font-black tracking-widest text-xs mr-8">SEARCH</span>
            <div className="w-[1px] h-6 bg-bronze/30 mr-8 hidden sm:block"></div>
            <input 
              type="text" 
              placeholder="Search inventory, models, or regions..." 
              className="flex-1 bg-transparent border-none outline-none text-zinc-600 text-sm italic font-serif placeholder:text-zinc-400"
            />
            <button className="text-bronze hover:text-black transition-colors ml-4">
              <Search size={24} />
            </button>
          </div>
        </div>

        {/* Main Footer Content */}
        <div className="max-w-[1600px] mx-auto px-8 py-20 border-b-[0.5px] border-white/10">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 lg:gap-8">
            
            {/* Col 1 */}
            <div>
               <div className="font-heading font-black text-3xl tracking-tighter text-white mb-4">
                  SCHOTSMAN<span className="text-bronze">.</span>
               </div>
               <p className="text-bronze font-heading font-bold tracking-widest text-xs uppercase mb-6">Experience. Integrity. Value.</p>
               <p className="text-neutral-500 font-light text-sm max-w-xs">
                 Global equipment trading experts based in the Netherlands and South Mississippi.
               </p>
            </div>

            {/* Col 2 */}
            <div>
               <h4 className="text-white font-heading font-bold tracking-widest text-sm uppercase mb-6">Quick Links</h4>
               <ul className="space-y-3 text-neutral-400 font-light text-sm">
                 <li><a href="#" className="hover:text-bronze transition-colors">New Equipment</a></li>
                 <li><a href="#" className="hover:text-bronze transition-colors">Used Equipment</a></li>
                 <li><a href="#" className="hover:text-bronze transition-colors">Sell Your Equipment</a></li>
                 <li><a href="#" className="hover:text-bronze transition-colors">About the Partners</a></li>
                 <li><a href="#" className="hover:text-bronze transition-colors">Global Trade Portal</a></li>
               </ul>
            </div>

            {/* Col 3 */}
            <div>
               <h4 className="text-white font-heading font-bold tracking-widest text-sm uppercase mb-6">Contact Us</h4>
               <ul className="space-y-4 text-neutral-400 font-light text-sm">
                 <li className="flex items-start">
                   <MapPin size={18} className="text-bronze mr-3 flex-shrink-0 mt-0.5" />
                   <span>European HQ<br/>The Netherlands</span>
                 </li>
                 <li className="flex items-start">
                   <MapPin size={18} className="text-bronze mr-3 flex-shrink-0 mt-0.5" />
                   <span>Americas Operations<br/>Hattiesburg, South Mississippi</span>
                 </li>
                 <li><a href="mailto:info@schotsman.llc" className="hover:text-white transition-colors">info@schotsman.llc</a></li>
               </ul>
            </div>

            {/* Col 4 */}
            <div>
               <h4 className="text-white font-heading font-bold tracking-widest text-sm uppercase mb-6">Connect</h4>
               <ul className="space-y-3 text-neutral-400 font-light text-sm">
                 <li><a href="#" className="flex items-center hover:text-white transition-colors"><div className="w-6 h-6 border border-bronze flex items-center justify-center rounded-sm mr-3 text-bronze">in</div> LinkedIn</a></li>
                 <li><a href="#" className="flex items-center hover:text-white transition-colors"><Settings size={18} className="mr-3 text-bronze" /> Industry Platforms</a></li>
               </ul>
            </div>

          </div>
        </div>

        {/* Copyright */}
        <div className="max-w-[1600px] mx-auto px-8 py-8 flex flex-col md:flex-row items-center justify-between text-neutral-600 text-xs font-light">
          <p>&copy; {new Date().getFullYear()} Schotsman LLC. All Rights Reserved.</p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
          </div>
        </div>

      </footer>

    </div>
  );
}
